#include <ioCC2530.h>
#include <string.h>
#include "light-vary.h"
#include "wenshi.h"
#include "hal_adc.h"

#define LED1 P1_4 
#define LED3 P1_0 
#define S5 P0_4 
#define DATA_PIN P0_0        //定义P0.5口为传感器输入端
  int pwmValue;
  int adcValue;





