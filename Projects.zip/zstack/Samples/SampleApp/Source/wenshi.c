#include <ioCC2530.h>
#include <string.h>
#include "wenshi.h"
void UartSendData(uint Data);
void UartSendString(char *Data,int len);

char TxTEMP[5];
char TxWET[4];
char TxDataWET[ARRAY_SIZE];
uint WET_R[2];
uint TEMP_R[2];
int shidu_shi=0,shidu_ge=0,wendu_shi=0,wendu_ge=0,shidu_fen=0,shidu_miao=0,wendu_fen=0,wendu_miao=0;
int wendu,shidu;

uchar CHECK_TEMP;
uchar CHECK_WENSHI;
uchar TEMP;
uchar TEMP_L;
uchar TEMP_H;
uchar WET_L;
uchar WET_H;

uchar ucharFLAG;
uchar TEMP;
uchar R_bit;
uchar WET_H_TEMP;
uchar WET_L_TEMP;
uchar TEP_H_TEMP;
uchar TEP_L_TEMP;
 
 
 
void Wait(uint16 timeout)
{
 while(timeout--)
 {
   asm("NOP");
   asm("NOP");
   asm("NOP");
 }
}


void Delay_us(uint i)
{
  while(i--);
 
}
void READ(void)
{
  uchar i;
  TEMP =0x00;
  for(i=0;i<8;i++)
  {
    ucharFLAG=2;
    while((!DATA_PIN)&&ucharFLAG++);
   
    Wait(40);
    if(DATA_PIN==1)
    {
      TEMP = TEMP | 0x01;
      ucharFLAG=2;
      while((DATA_PIN)&&ucharFLAG++);
    }
    else
    {
      TEMP = TEMP & 0xFE;
    }
    if(i<7)
    TEMP = TEMP<<1;
  }
}
void DHT11(void)
{
  P0SEL &=0xFE;
  P0DIR |= 0x01;
  DATA_PIN = 0;

  Wait(20000);
  DATA_PIN = 1;

  P0DIR &= ~0x01;
  Wait(30);
  if(!DATA_PIN)
  {

    ucharFLAG=2;
    while((!DATA_PIN)&&ucharFLAG++);
 
    ucharFLAG=2;
    while((DATA_PIN)&&ucharFLAG++);
 
    READ();
    WET_H_TEMP=TEMP;
    READ();
    WET_L_TEMP=TEMP;
    READ();
    TEP_H_TEMP=TEMP;
    READ();
    TEP_L_TEMP=TEMP;
    READ();
    CHECK_TEMP=TEMP;
    CHECK_WENSHI = (WET_H_TEMP+WET_L_TEMP+TEP_H_TEMP+ TEP_L_TEMP);

    if(CHECK_WENSHI == CHECK_TEMP)
    {  WET_H = WET_H_TEMP;
      WET_L = WET_L_TEMP;
      TEMP_H= TEP_H_TEMP;
      TEMP_L= TEP_L_TEMP;
      CHECK_WENSHI = CHECK_TEMP;
    }
        wendu=TEMP_H;
        wendu_shi=wendu/10; 
        wendu_ge=wendu%10;
        wendu=TEMP_L;
        wendu_fen=wendu/10; 
        wendu_miao=wendu%10;
        shidu=WET_H;
        shidu_shi= shidu/10; 
        shidu_ge=shidu%10;  
        shidu=WET_L;
        shidu_fen= shidu/10; 
        shidu_miao=shidu%10;
      
  }

   P0DIR |= 0x01;
}
 
 /*��ʱ*/
 void delay(uint n)
 {
   while(n--);
 }

 void Delay(uint n) 
 {
      uint i; 
      for(i = 0;i<n;i++);					
       for(i = 0;i<n;i++); 					
          for(i = 0;i<n;i++); 
          for(i = 0;i<n;i++); 
          for(i = 0;i<n;i++);					
} 
 