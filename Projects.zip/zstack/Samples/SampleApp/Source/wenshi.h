#include <ioCC2530.h>
#include <string.h>
typedef unsigned char uchar; 
typedef unsigned int uint;
typedef unsigned short int  uint16;
#define ARRAY_SIZE 2
#define TX_SIZE 20
#define TX_STRING1 "TEMP:"
#define TX_STRING2 "WET:"
extern char TxTEMP[5];
extern char TxWET[4];
extern uint WET_R[2];
extern uint TEMP_R[2];
extern char TxDataWET[ARRAY_SIZE];
#define S5 P0_4 
#define DATA_PIN P0_0        //定义P0.5口为传感器输入端
extern int shidu_shi,shidu_ge,wendu_shi,wendu_ge,shidu_fen,shidu_miao,wendu_fen,wendu_miao;
extern int wendu,shidu;

extern uchar ucharFLAG,TEMP,R_bit,WET_H_TEMP,WET_L_TEMP,TEP_H_TEMP,TEP_L_TEMP;
extern uchar CHECK_TEMP,CHECK_WENSHI,TEMP,TEMP_L,TEMP_H,WET_L,WET_H;


void Delay_us(uint i);
void READ(void);
void DHT11(void);
void Wait(uint16 timeout);

 void delay(uint); 
 void Delay(uint); 




