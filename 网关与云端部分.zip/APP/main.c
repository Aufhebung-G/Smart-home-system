/**
  ******************************************************************************
  * @copyright    CSU.EI.TE.first group
	* @filename     STM-WIFI
  * @description	Project/STM32F10x_StdPeriph_Template/main.c 
  * @author       ZYY
  * @version      V1.1.0
  * @date         13-7-2024
  * @brief        Main program body 
  ******************************************************************************
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "sys.h"
#include "led.h"
#include "timer.h"
#include "delay.h"
#include "usart.h"
#include "usart3.h"
#include "esp8266.h"
#include "string.h"

int main(int argc, char* argv[])
{

	u16 temp,humi;
	
	delay_init();	    	 			//��ʱ������ʼ��	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4); 			//����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 				//���ڳ�ʼ��Ϊ115200
	usart2_init(115200);	 				//���ڳ�ʼ��Ϊ115200
 
	esp8266_start_trans_staap();		//esp8266����STAAPģʽ��ʼ��
	
	while(1)
	{	
		MQTT_TX_temperature(temp, humi);
	}
	
	return 0;
}
