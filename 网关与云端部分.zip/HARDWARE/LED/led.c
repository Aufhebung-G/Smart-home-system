
#include "led.h" 
#include "delay.h"

void led_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_15|GPIO_Pin_12|GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_15;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_SetBits(GPIOC,GPIO_Pin_15|GPIO_Pin_12|GPIO_Pin_4|GPIO_Pin_5);
	GPIO_SetBits(GPIOA,GPIO_Pin_15);

}

void led_fllow(void)
{
	GPIO_ResetBits(GPIOC,GPIO_Pin_15);
	delay_ms(100);
	GPIO_SetBits(GPIOC,GPIO_Pin_15);
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_4);
	delay_ms(100);
	GPIO_SetBits(GPIOC,GPIO_Pin_4);
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_5);
	delay_ms(100);
	GPIO_SetBits(GPIOC,GPIO_Pin_5);
	
  GPIO_ResetBits(GPIOA,GPIO_Pin_15);
	delay_ms(100);
	GPIO_SetBits(GPIOA,GPIO_Pin_15);
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_12);
	delay_ms(100);
	GPIO_SetBits(GPIOC,GPIO_Pin_12);

	
}
void led_rainbow_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_8);
	
}	

void led_off(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
	GPIO_SetBits(GPIOA,GPIO_Pin_1);
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	delay_ms(1200);
}

void led_rainbow_flash(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	//delay_ms(800);
	
  GPIO_SetBits(GPIOA,GPIO_Pin_0);
	//delay_ms(10);
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	//delay_ms(800);

  GPIO_SetBits(GPIOA,GPIO_Pin_1);
	//delay_ms(10);
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	//delay_ms(800);

	GPIO_SetBits(GPIOA,GPIO_Pin_8);
	//delay_ms(10);
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
  //delay_ms(800);

  GPIO_SetBits(GPIOA,GPIO_Pin_1);
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
  //delay_ms(10);
	
  GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
  //delay_ms(800);

	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	GPIO_SetBits(GPIOA,GPIO_Pin_1);
  //delay_ms(10);

	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
 // delay_ms(800);

  GPIO_SetBits(GPIOA,GPIO_Pin_0);
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
 // delay_ms(10);

	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	//delay_ms(800);

  led_off();

}
