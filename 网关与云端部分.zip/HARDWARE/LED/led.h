#ifndef  __LED_H
#define  __LED_H
 //led1 pc15  led2  pc4  led3  pc5  led4  pa15()  led5  pc12
//RGB0  PA8  RGB1 PA0-WKUP   RGB2 PA1
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"

void led_init(void);
void led_fllow(void);
void led_rainbow_init(void);
void led_rainbow_flash(void);
void led_off(void);




#endif
