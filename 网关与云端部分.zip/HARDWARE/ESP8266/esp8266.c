#include "usart.h"
#include "usart3.h"
#include "delay.h"
#include "string.h"
#include "stm32f10x.h"
#include "esp8266.h"

char* atrestore="AT+RESTORE\r\n";    //����
char* AT="AT\r\n";	//echo
char* atcwmode="AT+CWMODE=3\r\n";	//����WiFiģʽ
char* atrst="AT+RST\r\n";	//����
char* atcwjap="AT+CWJAP=\"1001\",\"12345679\"\r\n";//����WIFI 

char* atmqttusercfg="AT+MQTTUSERCFG=0,1,\"NULL\",\"test&k1ko1viW76a\",\"dcdfe9549a4ac67971e9287d0d412b85de9e1769b7394bfe7af80964a7f8ec9a\",0,0,\"\"\r\n"; //����MQTT
char* atmqttclientid="AT+MQTTCLIENTID=0,\"k1ko1viW76a.test|securemode=2\\,signmethod=hmacsha256\\,timestamp=1721180386829|\"\r\n";
char* atmqttconn="AT+MQTTCONN=0,\"iot-06z00ar5rbp52cs.mqtt.iothub.aliyuncs.com\",1883,1\r\n";	//���Ӱ�����
char* atmqttsub="AT+MQTTSUB=0,\"/k1ko1viW76a/test/user/get\",1\r\n"; 	
char* atmqttsub_1="AT+MQTTSUB=0,\"/sys/k1ko1viW76a/test/thing/service/property/set\",0\r\n";	//���ı���

void esp8266_start_trans_staap(void)  
{
	USART2_SendString("+++");
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(AT);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atcwmode);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atrst);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atcwjap);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	
	USART2_SendString(atmqttusercfg);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atmqttclientid);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atmqttconn);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atmqttsub);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	USART2_SendString(atmqttsub_1);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);

}
void MQTT_TX_temperature(u16 temp, u16 humi){
	printf("AT+MQTTPUB=0,\"/sys/k1ko1viW76a/test/thing/event/property/post\",\"{\\\"params\\\":{\\\"temp\\\":%d\\,\\\"humi\\\":%d}\\,\\\"version\\\":\\\"1.0.0\\\"}\",0,0\r\n",temp,humi);	
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);

}



//������
//char* atmqttusercfg="AT+MQTTUSERCFG=0,1,\"k1kh36n7DBV|securemode=2\\,signmethod=hmacsha1\\,timestamp=1720925112183|\",\"Smart_greenhouse_1&k1kh36n7DBV\",\"3ECA783BE9AFE5C121E3C47DD6EA8BC28462CB0B\",0,0,\"\"\r\n";
//char* atmqttconn="AT+MQTTCONN=0,\"k1kh36n7DBV.iot-as-mqtt.cn-shanghai.aliyuncs.com\",1883,0\r\n";


//������
/*
char* atmqttusercfg="AT+MQTTUSERCFG=0,1,\"NULL\",\"STM32&k1l3jEHJseV\",\"6bf840fafbbeef4df11dc213d71d55a27118a6d2e332ef077cf44c4a935a1948\",0,0,\"\"\r\n";
char* atmqttclientid="AT+MQTTCLIENTID=0,\"k1l3jEHJseV.STM32|securemode=2\\,signmethod=hmacsha256\\,timestamp=1721150930345|\"\r\n";
char* atmqttconn="AT+MQTTCONN=0,\"iot-06z00gw19b1yie7.mqtt.iothub.aliyuncs.com\",1883,1\r\n";
char* atmqttsub="AT+MQTTSUB=0,\"/k1l3jEHJseV/STM32/user/get\",1\r\n";

char* atmqttsub_1="AT+MQTTSUB=0,\"/sys/k1l3jEHJseV/STM32/thing/service/property/set\",0";
char* atmqttpub="AT+MQTTPUB=0,\"/sys/k1l3jEHJseV/STM32/thing/event/property/post\",\"{\\\"params\\\":{\\\"CurrentTemperature\\\":25.0,\\\"CurrentHumidity\\\":30.0},\\\"version\\\":\\\"1.0.0\\\"}\",0,0";
*/


/*
char* atcifsr="AT+CIFSR\r\n";
char* atcipmux="AT+CIPMUX=0\r\n";
char* atcipmode="AT+CIPMODE=1\r\n";
char* atcipstart="AT+CIPSTART=\"UDP\",\"192.168.43.24\",10086\r\n";//??WIFI 
char* atcipsend="AT+CIPSEND\r\n";
*/
