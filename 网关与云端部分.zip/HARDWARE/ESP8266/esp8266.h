#ifndef __WIFI_H
#define __WIFI_H
#include "usart.h"
#include "delay.h"
#include "string.h"
#include "stm32f10x.h"
void esp8266_start_trans_staap(void);
void MQTT_TX_temperature(u16 temp, u16 humi);
#endif
