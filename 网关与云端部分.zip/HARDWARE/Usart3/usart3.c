#include "sys.h"
#include "delay.h"
#include "usart3.h"
#include "stdarg.h"	 	 
#include "stdio.h"	 	 
#include "string.h"	 
#include "timer.h" 
u8 UART2_data;
//uart1 
//bound:9600
void USART2_IRQHandler(void) {  
    u16 Res;  
   // if (USART_GetITStatus(UART4, USART_IT_RXNE) != RESET) {  
        Res = USART_ReceiveData(USART2);
        UART2_data = Res;  
  
       // while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) {}; 
        USART_SendData(USART1, Res);  
    //}  
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);  
}  

void usart2_init(u32 bound){
    //GPIO define
    GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	//open USART1,GPIOA clk
 	USART_DeInit(USART2);  //release uart1
	 //USART1_TX   PA.
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //PA.9
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//output mode
    GPIO_Init(GPIOA, &GPIO_InitStructure); // Set PA9
   
    //USART1_RX	  PA.10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//
    GPIO_Init(GPIOA, &GPIO_InitStructure);  //Set PA10

   //Usart1 NVIC

  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=5 ;//
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		//
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//
	NVIC_Init(&NVIC_InitStructure);	//
  
   //USART1

	USART_InitStructure.USART_BaudRate = bound;//9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//
	USART_InitStructure.USART_Parity = USART_Parity_No;//
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//

    USART_Init(USART2, &USART_InitStructure); //
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);//
    USART_Cmd(USART2, ENABLE);                    //

}


void USART2_SendByByter(u8 Data){
	//
	USART_GetFlagStatus(USART2, USART_FLAG_TC);	
	USART_SendData(USART2, Data);
	while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);	
}

void USART2_SendString(char* str){
	//while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
	while(*str)
	{
		USART_ClearITPendingBit(USART2, USART_FLAG_TXE);
		USART_SendData(USART2,(uint16_t) *str++);
		while(USART_GetFlagStatus(USART2, USART_FLAG_TXE)== RESET);
	}
}

